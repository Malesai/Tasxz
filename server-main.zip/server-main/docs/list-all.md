
# slot_win_x64 list --all

```text
'100 Jokers' AGT 5x4 videoslot
'100 Shining Stars' AGT 5x4 videoslot
'2 Million B.C.' BetSoft 5x3 videoslot
'40 Bigfoot' AGT 5x4 videoslot
'5 Hot Hot Hot' AGT 3x3 videoslot
'50 Apples' Shine' AGT 5x4 videoslot
'50 Gems' AGT 5x4 videoslot
'50 Happy Santa' AGT 5x4 videoslot
'AI' AGT 5x3 videoslot
'African Simba' Novomatic 5x3 videoslot
'Age of Heroes' Novomatic 5x3 videoslot
'Aladdin' AGT 5x4 videoslot
'Always American' Novomatic 3x3 videoslot
'Always Hot' Novomatic 3x3 videoslot
'Always Hot Deluxe' Novomatic 3x3 videoslot
'American Keno' Aristocrat 80 spots lottery
'Angry Birds' Novomatic 5x3 videoslot
'Anonymous' AGT 5x3 videoslot
'Apples' Shine' AGT 5x3 videoslot
'Arabian Nights' AGT 5x3 videoslot
'Arabian Nights' NetEnt 5x3 videoslot
'Arabian Nights 2' AGT 5x4 videoslot
'Around The World' AGT 5x4 videoslot
'At the Movies' BetSoft 5x3 videoslot
'Attila' Novomatic 5x3 videoslot
'Aztec Gold' Megajack 5x3 videoslot
'Banana Splash' Novomatic 5x3 videoslot
'Bananas Go Bahamas' Novomatic 5x3 videoslot
'Beetle Mania' Novomatic 5x3 videoslot
'Beetle Mania Deluxe' Novomatic 5x3 videoslot
'Big Five' AGT 5x3 videoslot
'Bigfoot' AGT 5x3 videoslot
'Bitcoin' AGT 5x3 videoslot
'Book of Ra' Novomatic 5x3 videoslot
'Book of Ra Deluxe' Novomatic 5x3 videoslot
'Book of Set' AGT 5x3 videoslot
'Captain's Treasure' Playtech 5x3 videoslot
'Cash Farm' Novomatic 5x3 cascade videoslot
'Casino' AGT 5x4 videoslot
'Champagne' Megajack 5x3 videoslot
'Cherry Hot' AGT 5x3 videoslot
'Chicago' Novomatic 5x3 videoslot
'Cleopatra' IGT 5x3 videoslot
'Cold Spell' Novomatic 5x3 videoslot
'Columbus' Novomatic 5x3 videoslot
'Columbus Deluxe' Novomatic 5x3 videoslot
'Cops'n'Robbers' Play'n GO 5x3 videoslot
'Crown' AGT 5x4 videoslot
'Desert Treasure' Playtech 5x3 videoslot
'Diamond 7' Novomatic 5x3 videoslot
'Diamond Dogs' NetEnt 5x3 videoslot
'Dolphin Treasure' Aristocrat 5x3 videoslot
'Dolphins Pearl' Novomatic 5x3 videoslot
'Dolphins Pearl Deluxe' Novomatic 5x3 videoslot
'Double Diamond' IGT 3x3 videoslot
'Double Hot' AGT 3x3 videoslot
'Double Ice' AGT 3x3 videoslot
'Down Under' Novomatic 5x3 videoslot
'Dragon's Deep' Novomatic 5x3 videoslot
'Dynasty Of Ming' Novomatic 5x3 videoslot
'Dynasty of Ra' Novomatic 5x3 videoslot
'Egypt' AGT 5x3 videoslot
'Excalibur' NetEnt 5x3 videoslot
'Extra Spin' AGT 5x3 videoslot
'Extra Spin III' AGT 5x3 videoslot
'Fairy Queen' Novomatic 5x3 videoslot
'Faust' Novomatic 5x3 videoslot
'Fire Joker' Play'n GO 5x3 videoslot
'Fire Keno' Slotopol 80 spots lottery
'Firefighters' AGT 5x3 videoslot
'Flame Dancer' Novomatic 5x3 videoslot
'Flowers' NetEnt 5x3 videoslot
'Fortune Teller' Play'n GO 5x3 videoslot
'Fruit Queen' AGT 5x6 videoslot
'Fruit Sensation' Novomatic 5x3 videoslot
'Fruit Shop' NetEnt 5x3 videoslot
'Fruitilicious' Novomatic 5x3 videoslot
'Fruits'n Royals' Novomatic 5x3 videoslot
'Funky Seventies' NetEnt 5x4 videoslot
'Gate of Ra Deluxe' Novomatic 5x3 videoslot
'Geisha Wonders' NetEnt 5x3 videoslot
'Gems' AGT 5x3 videoslot
'God of Sun' Novomatic 5x3 videoslot
'Golden Prophecies' Novomatic 5x3 videoslot
'Golden Tour' Playtech 5x3 videoslot
'Gonzo's Quest' NetEnt 5x3 cascade videoslot
'Grand Theft' AGT 5x3 videoslot
'Great Blue' Playtech 5x3 videoslot
'Green Hot' AGT 5x3 videoslot
'Groovy Sixties' NetEnt 5x4 videoslot
'Gryphons Gold' Novomatic 5x3 videoslot
'Gryphons Gold Deluxe' Novomatic 5x3 videoslot
'Halloween' AGT 3x3 videoslot
'Happy Santa' AGT 5x3 videoslot
'Helena' Novomatic 5x3 videoslot
'Holmes and Watson Deluxe' Novomatic 5x3 videoslot
'Hot Clover' AGT 5x4 videoslot
'Hot Cubes' Novomatic 5x3 videoslot
'Hot Target' Novomatic 5x3 videoslot
'Ice Fruits' AGT 5x3 videoslot
'Ice Ice Ice' AGT 3x3 videoslot
'Ice Queen' AGT 5x3 videoslot
'Indian Dreaming' Aristocrat 5x3 videoslot
'Inferno' Novomatic 5x3 videoslot
'Infinity Gems' AGT 5x3 videoslot
'Irish Luck' Playtech 5x3 videoslot
'Jaguar Moon' Novomatic 5x3 videoslot
'Jewels' Novomatic 5x3 videoslot
'Jewels 4 All' Novomatic 5x3 videoslot
'Joker Dolphin' Novomatic 5x3 videoslot
'Jokers' AGT 5x3 videoslot
'Just Fruits' Novomatic 5x3 videoslot
'Just Jewels' Novomatic 5x3 videoslot
'Just Jewels Deluxe' Novomatic 5x3 videoslot
'Katana' Novomatic 5x3 videoslot
'Keno Centurion' Slotopol 80 spots lottery
'Keno Fast' AGT 80 spots lottery
'Keno Luxury' Aristocrat 80 spots lottery
'Keno Sports' Aristocrat 80 spots lottery
'King Of Cards' Novomatic 5x3 videoslot
'King's Jester' Novomatic 5x3 videoslot
'Lord of the Ocean' Novomatic 5x3 videoslot
'Lovely Mermaid' Novomatic 5x4 videoslot
'Lucky Lady's Charm' Novomatic 5x3 videoslot
'Lucky Lady's Charm Deluxe' Novomatic 5x3 videoslot
'Lucky Slot' AGT 5x3 videoslot
'Marco Polo' Novomatic 5x3 videoslot
'Mega Joker' Novomatic 5x4 videoslot
'Mega Shine' AGT 5x3 videoslot
'Mermaid's Pearl' Novomatic 5x3 videoslot
'Merry Christmas' AGT 3x3 videoslot
'Oliver's Bar' Novomatic 5x3 videoslot
'Panda' AGT 3x3 videoslot
'Pandora's Box' NetEnt 5x3 videoslot
'Panther Moon' Playtech 5x3 videoslot
'Pharaoh II' AGT 5x3 videoslot
'Pharaoh's Gold II' Novomatic 5x3 videoslot
'Pharaoh's Gold III' Novomatic 5x3 videoslot
'Piggy Riches' NetEnt 5x3 videoslot
'Pirates Gold' AGT 5x3 videoslot
'Plenty of Fruit 20 hot' Novomatic 5x3 videoslot
'Plenty of Jewels 20 hot' Novomatic 5x3 videoslot
'Plenty on Twenty' Novomatic 5x3 videoslot
'Polar Fox' Novomatic 5x3 videoslot
'Power Stars' Novomatic 5x3 videoslot
'Ramses II' Novomatic 5x3 videoslot
'Red Crown' AGT 5x4 videoslot
'Redroo' Aristocrat 5x4 videoslot
'Reel Steal' NetEnt 5x3 videoslot
'Rich Girl' IGT 5x3 videoslot
'Roaring Forties' Novomatic 5x4 videoslot
'Royal Dynasty' Novomatic 5x3 videoslot
'Royal Jewels' Novomatic 5x3 videoslot
'Royal Treasures' Novomatic 5x3 videoslot
'STALKER' AGT 5x3 videoslot
'Safari Heat' Playtech 5x3 videoslot
'Santa' AGT 4x4 videoslot
'Secret Elixir' Novomatic 5x3 videoslot
'Secret Forest' Novomatic 5x3 videoslot
'Secret Of Horus' NetEnt 5x3 videoslot
'Seven Hot' AGT 5x3 videoslot
'Shining Stars' AGT 5x3 videoslot
'Simsalabim' NetEnt 5x3 videoslot
'Sizzling Hot' Novomatic 5x3 videoslot
'Sizzling Hot Deluxe' Novomatic 5x3 videoslot
'Slotopol' Megajack 5x3 videoslot
'Slotopol Deluxe' Megajack 5x3 videoslot
'Spellcast' NetEnt 5x3 videoslot
'Sun City' AGT 5x3 videoslot
'Super Eighties' NetEnt 5x4 videoslot
'Sushi Bar' BetSoft 5x3 videoslot
'Tesla' AGT 5x3 videoslot
'The Leprechaun' AGT 5x3 videoslot
'The Money Game' Novomatic 5x3 videoslot
'The Money Game Deluxe' Novomatic 5x3 videoslot
'The Real King Gold Records' Novomatic 5x3 videoslot
'Thrill Spin' NetEnt 5x3 videoslot
'Tiki Wonders' NetEnt 5x3 videoslot
'Time Machine II' AGT 5x3 videoslot
'Triple Diamond' IGT 3x3 videoslot
'Trolls' NetEnt 5x3 videoslot
'Tropic Hot' AGT 3x3 videoslot
'Ultra Gems' Novomatic 3x3 videoslot
'Ultra Hot' Novomatic 3x3 videoslot
'Ultra Hot Deluxe' Novomatic 3x3 videoslot
'Ultra Sevens' Novomatic 5x4 videoslot
'Unicorn Magic' Novomatic 5x3 videoslot
'Valentine's Day' AGT 5x3 videoslot
'Valkyrie' AGT 5x3 videoslot
'Viking's Treasure' NetEnt 5x3 videoslot
'Voodoo Vibes' NetEnt 5x3 videoslot
'Wild West' AGT 5x4 videoslot
'Wild Witches' NetEnt 5x3 videoslot
'Wizard' AGT 5x4 videoslot
'Wolf Run' IGT 5x4 videoslot

total: 195 games, 103 algorithms, 10 providers
AGT: 60 games
Aristocrat: 6 games
BetSoft: 3 games
IGT: 5 games
Megajack: 4 games
NetEnt: 22 games
Novomatic: 83 games
Play'n GO: 3 games
Playtech: 7 games
Slotopol: 2 games
```
